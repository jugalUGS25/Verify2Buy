const APISetting= {
     apiurl: 'https://api.universumgs.com/api',
   //local url: http://demo.solfordoc.com:8080/api',
}